<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

/// 
/// \file   ${NAME}.${EXTENSION}
/// \author ${user}
///
/// \date ${DATE}, ${TIME}
///

#include ${QUOTES}${NAME}.${DEFAULT_HEADER_EXT}${QUOTES}
